# Remove NitroPack Footer for Joan Morales | WordPress Developer 
# https://joanmorales.com/remove-nitropack-footer/

## Descripción
**Remove NitroPack Footer** es un plugin de WordPress que oculta automáticamente el footer molestoso de NitroPack en tu versión gratuita. E


## Instalación
### Método 1: Instalación manual
1. Descarga el archivo ZIP del plugin o clona el repositorio.
2. Extrae el contenido en la carpeta `wp-content/plugins/remove_nitropack_footer/`.
3. Activa el plugin desde el panel de administración de WordPress en **Plugins > Plugins instalados**.

### Método 2: Instalación desde el panel de WordPress
1. Ve a **Plugins > Añadir nuevo**.
2. Haz clic en **Subir plugin** y selecciona el archivo ZIP del plugin.
3. Instala y activa el plugin.

## Uso
- No requiere configuración manual.
- Se ejecuta automáticamente en todas las páginas de tu WordPress.
